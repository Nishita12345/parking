package com.example.parking

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
