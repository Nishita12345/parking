import 'package:flutter/material.dart';
import 'package:parking/screens/drawer_page.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:parking/user_auth/sign_up.dart';

class SecondPage extends StatefulWidget {

  @override
  _SecondPageState createState() => _SecondPageState();
}

class _SecondPageState extends State<SecondPage> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: Colors.pink,
        title: Text(''),
      ),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            colorFilter: ColorFilter.mode(Colors.black.withOpacity(0.8), BlendMode.dstATop ),
            image: AssetImage('images/image2.jpg'),
            fit: BoxFit.cover,
          ),

        ),
        width: double.infinity,
        child: Column(
          children: <Widget>[
            SizedBox( height: 60.0 ,),
            Text('ParkPort', style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.pinkAccent,
              fontSize: 40.0,
            ),
            ),
            SizedBox( height: 60.0 ,),
            SizedBox( height: 60.0 ,),
            Column(
              children: [
               Padding(
                 padding: const EdgeInsets.only(left:15.0, right : 15.0),
                 child: TextFormField(
                   decoration: InputDecoration(
                     filled: true,
                     fillColor: Colors.white,
                     border: OutlineInputBorder(),
                     labelText: 'Enter your email id',
                   ),
                   validator: MultiValidator([
                     RequiredValidator(errorText: 'Enter the required field'),
                     EmailValidator(errorText: 'Enter valid email id'),
                   ],
                   ),
                   obscureText: false,
                 ),
               ),
                SizedBox(height : 15.0),
                Padding(
                  padding: const EdgeInsets.only(left:15.0, right : 15.0),
                  child: TextFormField(
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(),
                      labelText: 'Enter password',
                    ),
                    validator: MultiValidator([
                      RequiredValidator(errorText: 'Enter the required field'),
                      MinLengthValidator(6, errorText: 'Password should be greater than 6 characters'),
                      MaxLengthValidator(12, errorText : 'Password should be less than 12 characters'),
                    ],
                    ),
                    obscureText: true,
                  ),
                ),
              ],
            ),
            SizedBox(height: 30.0,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(onPressed: () {},
                  style:  ElevatedButton.styleFrom(
                    primary: Colors.blueAccent,
                  ),
                  child: Text('Login with Google'),
                ),
                SizedBox(width: 20.0,),
                ElevatedButton(onPressed: () {},
                  style:  ElevatedButton.styleFrom(
                    primary: Colors.blueAccent,
                  ),
                  child: Text('Login with FaceBook'),
                ),
              ],
            ),
            ElevatedButton(onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => DrawerNavigationPage()),
              );
            },
              style: ElevatedButton.styleFrom(
                primary: Color(0xFF370A3E),
              ),
              child: Text('Login'),
            ),
            SizedBox(height: 30,),
            ElevatedButton(onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => SignupPage()),
              );
            },
              style: ElevatedButton.styleFrom(
                primary: Color(0xFF370A3E),
              ),
              child: Text('Not having an account? sign up'),
            ),
          ],
        ),
      ),
    );
  }
}
